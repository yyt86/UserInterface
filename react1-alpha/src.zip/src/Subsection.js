import React from 'react'
import './App.css'
import "./subsection.css"

class Subsection extends React.Component{
	render(){

	let sub_sections = this.props.section[this.props.num].subsections;
   //  console.log(this.props.cartMode)
	 return Object.keys(sub_sections).map((key,index) => {
	   return (
 
		 <div key={this.props.data.number + this.props.section[this.props.num].number + sub_sections[key].number}>
			 <ul>
				 <li className="num_s">{sub_sections[key].number}
		 
		 {this.props.cartMode? <button onClick={() => {this.props.removecart(this.props.data, this.props.num, key );}}>Remove Subsection</button> : 
		  <button onClick={() => {this.props.addtocart(this.props.data, this.props.num, key ) }}>Add Subsection</button>}
				 </li>			
			 <ul className=".ul3">
				 <li>{sub_sections[key].location}</li>
				 <li>Metting Times
				 <ul className=".ul4">
					 {Object.keys(sub_sections[key].time).map((k, i) => (
					 <li key={k}>{k}: {sub_sections[key].time[k]}</li>))}
					 </ul>
				 </li>
			 </ul>
			 </ul>
		 </div>)})	
	 
 }
}

export default Subsection
