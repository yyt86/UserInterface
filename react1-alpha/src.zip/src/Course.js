import React from 'react';
import './App.css';
import Section from './Section'
import "./course.css"

class Course extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      addSection: "",
      addSubsection: "",
      cart: []
    }
}
  
  

  getReq (arr){
    if (arr.length === 0){
      return "None"
    }
    else if(arr[0].constructor === Array){
      
      let list=[];
      for(const item of arr.values()){
        if(item.length > 1)
          list.push(item.join(" OR "))
        else
          list.push(item)
      }
      let list1 = list.map(x =>("("+x+")"))
      return list1.join(" AND ")
    }
    
  }


  render(){
    // console.log(this.props.data.number);
    const course = this.props.data;
    
    return (
      
      <div>
         
            <p className="head"><span>({course.number}) {course.name} |</span><span className="credit"> ({course.credits} Credits)   </span>
            {this.props.cartMode ? <button onClick={() => {this.props.removecart(this.props.data, null, null );}}>Remove Course</button> : 
         <button onClick={() => {this.props.addtocart(this.props.data, null, null ) }}>Add Course</button>}  </p>
            <p className="subject">Subject: {course.subject}</p>
            <p className="des">{course.description}</p>
            <p className="req"><span className="req_title">Requisites: </span><span>{this.getReq(course.requisites)}</span></p>
            <p className="key"><u>Keywords: </u> <span> {course.keywords.join(', ')}</span></p>
            <p className="sec" key={course.name}>Sections</p>
            <div className="secs">
             <Section key={course.sections.number} data={this.props.data} addtocart={this.props.addtocart} removecart={this.props.removecart} cartMode={this.props.cartMode} />
            </div>
            <br/>
            <br/> 
      </div>
    )
  
  }
}


export default Course
