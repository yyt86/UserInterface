import React from 'react'
import './App.css'
import Subsection from './Subsection.js'
import "./section.css"


class Section extends React.Component {
	render(){
		let sections = this.props.data.sections
		var s = [];

	if(sections != null ){
	  if(Object.values(sections).some(e => Object.keys(e.subsections).length !== 0)){
		s.push(<p className="sub_s" key="subsection_text">Subsections</p>) 
	  }
	}
	return Object.keys(sections).map((key,index) => {
	 
	  return (
	<div key={this.props.data.number + sections[key].number}>
		
	  <ul className=".ul0">
		<li className="head_s">{sections[key].number} 
		{this.props.cartMode ? <button onClick={() => {this.props.removecart(this.props.data, key, null );}}>Remove Section</button> : 
		   <button onClick={() => {this.props.addtocart(this.props.data, key, null ) }}>Add Section</button>}
		 
  
		</li>			
	  <ul className=".ul1">
		<li>Instructor: {sections[key].instructor}</li>
		<li>Location: {sections[key].location}</li>
		<li>Metting Times
		<ul className=".ul2">
		  {Object.keys(sections[key].time).map((k, i) => (
		  <li key={k}>{k}: {sections[key].time[k]}</li>))}
		  </ul>
		</li>
	  </ul>
	  </ul>
	   {s}     
	  <div>
	  <Subsection data={this.props.data} addtocart={this.props.addtocart} removecart={this.props.removecart} cartMode={this.props.cartMode} section={sections} num={key}/>
		
  
	   </div>
  
	</div>)})}	
	
  }
        
  export default Section
        



